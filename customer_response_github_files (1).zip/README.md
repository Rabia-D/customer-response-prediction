# Predictive Customer Analytics

**Can machine learning identify which customers are most likely to respond to a marketing campaign?**

I analyzed a supermarket customer dataset with **2,240 records**, cleaned the data, explored spending and engagement patterns, and trained three classification models to predict `Campaign_Response`.

## Questions

- Which customer characteristics are associated with campaign response?
- Can a classifier improve on simply predicting that no customer responds?
- Which model balances precision and recall best?

## Dataset & models

The original dataset contains **2,240 customers**. After cleaning, the modelling split used **1,788 training** and **448 test** records (80/20, stratified). Only **14.96%** of test customers responded, making this an imbalanced classification problem.

I trained **K-Nearest Neighbors (KNN)**, **Support Vector Machine (RBF SVM)**, and **Logistic Regression**, with scaled numeric features and encoded categorical features. KNN's neighbor count was selected using 5-fold cross-validation on the training set.

## Results

| Model | Test accuracy | Test F1 |
| --- | ---: | ---: |
| Majority-class baseline | 85.1% | 0.000 |
| KNN | 85.7% | 0.347 |
| SVM (RBF) | **87.7%** | 0.353 |
| **Logistic Regression** | 86.8% | **0.379** |

**Logistic Regression had the best F1 score**, with **64.29% precision** and **26.87% recall** on the positive-response class. SVM had the highest accuracy, but accuracy alone is misleading when most customers do not respond. The best-F1 model still missed many responders.

![Confusion matrix for Logistic Regression](figures/confusion_matrix.png)

## What the data showed

- **Spending mattered:** Total spending had the strongest positive correlation with response among the numeric features examined (**r = 0.266**); recency had the strongest negative correlation (**r = −0.199**).
- **Response varied by education:** The observed response rate ranged from **3.70%** for Basic education to **20.82%** for PhD. This is descriptive, not evidence of causation.
- **Purchases were mostly in-store:** Store purchases accounted for **46.19%** of recorded purchases, versus **32.58%** web and **21.23%** app.

![Campaign response by education](figures/response_by_education.png)

![Correlation analysis](figures/feature_correlations.png)

Additional notebook figures: [Spending by category](figures/spending_by_category.png) · [Recency vs. spending](figures/recency_vs_spending.png) · [Purchase channel mix](figures/purchase_channel_mix.png)

## Code

[`customer_response_prediction.ipynb`](customer_response_prediction.ipynb) contains the data preparation, visualizations, model training, and evaluation. Built with **Python, Pandas, NumPy, Matplotlib, Seaborn, and scikit-learn**.

To reproduce it, open the notebook in Colab and provide `Supermarket_Customer_Dataset.csv` at the path used in the notebook (`/content/Supermarket_Customer_Dataset.csv`). The dataset is not bundled here.

*Exploratory coursework-based project; models have not been deployed or validated on new populations.*
